import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelhotelComponent } from './hotelhotel.component';

describe('HotelhotelComponent', () => {
  let component: HotelhotelComponent;
  let fixture: ComponentFixture<HotelhotelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HotelhotelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelhotelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
