import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelhotel',
  templateUrl: './hotelhotel.component.html',
  styleUrls: ['./hotelhotel.component.scss']
})
export class HotelhotelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
