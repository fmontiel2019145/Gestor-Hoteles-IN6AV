import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaulthotelComponent } from './defaulthotel.component';

describe('DefaulthotelComponent', () => {
  let component: DefaulthotelComponent;
  let fixture: ComponentFixture<DefaulthotelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaulthotelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaulthotelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
