import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Habitaciones } from 'src/app/models/habitaciones';
import { HotelsService } from 'src/app/services/hotels.service';
import { UsersService } from 'src/app/services/users.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-defaulthotel',
  templateUrl: './defaulthotel.component.html',
  styleUrls: ['./defaulthotel.component.scss']
})
export class DefaulthotelComponent implements OnInit {

  habitacion: Habitaciones = {
    idHotel : "",
    idHabitacion : "",
    descripcionHabitacion : "",
    categoriaHabitacion : "",
    costoHabitacion : 0
  };

  hotel: any = [];

  constructor(private router: ActivatedRoute, private hotelsService: HotelsService, private usersService: UsersService) {
    var idHotel = this.router.snapshot.params['idHotel'];

    if(!localStorage.getItem("token")){
      Swal.fire({
        title: 'Aviso',
        text: 'Para reservar necesitas estar registrado, se te redirigirá al inicio de sesion',
        icon: 'warning',
        confirmButtonText: 'Ok'
      }).then(() => {
        window.location.href = "http://localhost:4200/login?next=hotel/"+idHotel;
      });
    }
  }

  ngOnInit(): void {
    var idHotel = this.router.snapshot.params['idHotel'];
    this.usersService.autoRedirect("/hotel/client/"+idHotel, "/hotel/hotel/"+idHotel, "/hotel/admin/"+idHotel, false);
    this.hotelsService.getHotel(idHotel).subscribe(res => {
      this.hotel = res['data'];
    }, err =>  console.error(err));
  }
}
