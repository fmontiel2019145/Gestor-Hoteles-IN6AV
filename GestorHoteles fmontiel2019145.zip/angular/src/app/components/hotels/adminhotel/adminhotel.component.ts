import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HotelsService } from 'src/app/services/hotels.service';
import { RoomsService } from 'src/app/services/rooms.service';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-adminhotel',
  templateUrl: './adminhotel.component.html',
  styleUrls: ['./adminhotel.component.scss']
})
export class AdminhotelComponent implements OnInit {

  hotel: any = [];
  habitaciones: any = [];

  constructor(private roomsService: RoomsService, private router: ActivatedRoute, private hotelsService: HotelsService, private usersService: UsersService) { }

  ngOnInit(): void {
    var idHotel = this.router.snapshot.params['idHotel'];
    this.usersService.autoRedirect("/hotel/"+idHotel, "/hotel/hotel/"+idHotel, false, "/hotel/"+idHotel);
    this.hotelsService.getHotel(idHotel).subscribe(res => {
      this.hotel = res['data'];
      var temp = res['data'];
      temp['habitacionesHotel'].forEach(habitacion => {
        this.roomsService.getRoom({idRoom : habitacion['_id']}).subscribe(resD => {
          var newData = habitacion;
          var tempReservacion: any = resD;
          if(tempReservacion.length > 0){
            if(tempReservacion.fechaEntradaPedido < new Date() && tempReservacion.fechaSalidaPedido > new Date()){
              newData['estadoHotel'] = "Reservado";
            }else{
              newData['estadoHotel'] = "No reservado";
            }
          }else{
            newData['estadoHotel'] = "No reservado";
          }
          this.habitaciones.push(newData);
          //this.hotel = res['data'];
        }, err =>  console.error(err));
      });
    }, err =>  console.error(err));
  }

}
