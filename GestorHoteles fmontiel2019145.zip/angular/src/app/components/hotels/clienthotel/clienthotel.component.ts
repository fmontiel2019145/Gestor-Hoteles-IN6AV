import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Habitaciones } from 'src/app/models/habitaciones';
import { HotelsService } from 'src/app/services/hotels.service';
import { RoomsService } from 'src/app/services/rooms.service';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-clienthotel',
  templateUrl: './clienthotel.component.html',
  styleUrls: ['./clienthotel.component.scss']
})
export class ClienthotelComponent implements OnInit {
  hotel: any = [];
  habitaciones: any = [];

  constructor(private roomsService: RoomsService, private router: ActivatedRoute, private hotelsService: HotelsService, private usersService: UsersService) { }

  ngOnInit(): void {
    var idHotel = this.router.snapshot.params['idHotel'];
    this.usersService.autoRedirect(false, "/hotel/hotel/"+idHotel, "/hotel/admin/"+idHotel, "/hotel/"+idHotel);
    this.hotelsService.getHotel(idHotel).subscribe(res => {
      var temp = res['data'];
      temp['habitacionesHotel'].forEach(habitacion => {
        this.roomsService.getRoom({idRoom : habitacion['_id']}).subscribe(resD => {
          var newData = habitacion;
          var tempReservacion: any = resD;
          if(tempReservacion.length > 0){
            if(tempReservacion.fechaEntradaPedido < new Date() && tempReservacion.fechaSalidaPedido > new Date()){
              newData['estadoHotel'] = "Reservado";
            }else{
              newData['estadoHotel'] = "No reservado";
            }
          }else{
            newData['estadoHotel'] = "No reservado";
          }
          this.hotel = res['data'];
          this.habitaciones.push(newData);
          //this.hotel = res['data'];
        }, err =>  console.error(err));
      });
    }, err =>  console.error(err));
  }

}
