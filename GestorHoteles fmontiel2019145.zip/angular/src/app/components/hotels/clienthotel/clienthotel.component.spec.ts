import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClienthotelComponent } from './clienthotel.component';

describe('ClienthotelComponent', () => {
  let component: ClienthotelComponent;
  let fixture: ComponentFixture<ClienthotelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClienthotelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ClienthotelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
