import { Component, OnInit } from '@angular/core';
import { HotelsService } from 'src/app/services/hotels.service';

@Component({
  selector: 'app-hotelslist',
  templateUrl: './hotelslist.component.html',
  styleUrls: ['./hotelslist.component.scss']
})
export class HotelslistComponent implements OnInit {

  hotels:any = [];
  constructor(private hotelsService:HotelsService) { }

  ngOnInit(): void {
    this.hotelsService.getHotels().subscribe(
      res => {
        this.hotels = res;
      }, err => console.error(err)
    );
  }

}
