import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HotelsheaderComponent } from './hotelsheader.component';

describe('HotelsheaderComponent', () => {
  let component: HotelsheaderComponent;
  let fixture: ComponentFixture<HotelsheaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HotelsheaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HotelsheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
