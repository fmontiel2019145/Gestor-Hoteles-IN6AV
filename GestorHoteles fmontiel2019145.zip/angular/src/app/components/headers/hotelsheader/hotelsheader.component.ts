import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hotelsheader',
  templateUrl: './hotelsheader.component.html',
  styleUrls: ['./hotelsheader.component.scss']
})
export class HotelsheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
