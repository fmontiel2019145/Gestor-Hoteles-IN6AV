import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-defaultheader',
  templateUrl: './defaultheader.component.html',
  styleUrls: ['./defaultheader.component.scss']
})
export class DefaultheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
