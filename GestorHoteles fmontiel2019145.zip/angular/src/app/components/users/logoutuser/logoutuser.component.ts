import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-logoutuser',
  templateUrl: './logoutuser.component.html',
  styleUrls: ['./logoutuser.component.scss']
})
export class LogoutuserComponent implements OnInit {

  constructor() { 
    Swal.fire({
      title: 'Saliendo',
      text: 'Estas cerrando sesión!',
      icon: 'success',
      confirmButtonText: 'Ok'
    }).then(() => {
      if(localStorage.getItem("token")){
        localStorage.removeItem("token");
      }
      
      window.location.href = "home";
    });
  }

  ngOnInit(): void {
  }

}
