import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';
import { UsersService } from 'src/app/services/users.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-profileuser',
  templateUrl: './profileuser.component.html',
  styleUrls: ['./profileuser.component.scss']
})
export class ProfileuserComponent implements OnInit {
  userForm: User = {
    idUsuario: "",
    apodoUsuario: "",
    nombreUsuario: "",
    correoUsuario: "",
    claveUsuario: "",
    fechaNacUsuario: new Date()
  };

  sesion: any = { 
    data: {
      _id: null,
      apodoUsuario: null,
      nombreUsuario: "",
      correoUsuario: "",
      claveUsuario: "",
      fechaNacUsuario: null
    }
  };

  constructor(private usersService: UsersService) {}

  ngOnInit(): void {
    if(localStorage.getItem("token")){
      this.usersService.getUser().subscribe(
        res => {
          this.sesion = res;
          this.userForm.idUsuario = this.sesion.data._id;
          this.userForm.apodoUsuario = this.sesion.data.apodoUsuario;
          this.userForm.nombreUsuario = this.sesion.data.nombreUsuario;
          this.userForm.correoUsuario = this.sesion.data.correoUsuario;
          this.userForm.fechaNacUsuario = new Date(this.sesion.data.fechaNacUsuario);
        },err => console.error(err)
      );
    }else{
      window.location.href = "/home";
    }
  }

  updateUser(){
    this.usersService.updateUser(this.userForm).subscribe(
      res => {
        this.sesion = res;
        
        if(this.sesion.token){
          localStorage.removeItem("token");
          localStorage.setItem("token", this.sesion.token);

          this.userForm.idUsuario = this.sesion.data._id;
          this.userForm.apodoUsuario = this.sesion.data.apodoUsuario;
          this.userForm.nombreUsuario = this.sesion.data.nombreUsuario;
          this.userForm.correoUsuario = this.sesion.data.correoUsuario;

          this.sesion = res;

          Swal.fire({
            title: 'Listo!',
            text: 'Datos cambiados',
            icon: 'success',
            confirmButtonText: 'Ok'
          });

        }else{
          Swal.fire({
            title: 'Error!',
            text: this.sesion.error,
            icon: 'error',
            confirmButtonText: 'Ok'
          });
        }
        
      },err => console.error(err));
  }

  deleteUser(){

  }
}
