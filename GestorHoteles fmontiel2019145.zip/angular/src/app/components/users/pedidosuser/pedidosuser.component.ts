import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-pedidosuser',
  templateUrl: './pedidosuser.component.html',
  styleUrls: ['./pedidosuser.component.scss']
})
export class PedidosuserComponent implements OnInit {

  pedidos: any = [];

  constructor(private usersService: UsersService) { }

  ngOnInit(): void {
    this.usersService.getUser().subscribe(res => {
      res['data']['pedidosUsuario'].forEach(element => {
        if(element.fechaEmisionPedido && element.fechaSalidaPedido && element.fechaEntradaPedido){
          this.pedidos.push(element);
        }
      });
      
    }, err => console.error(err));
  }

}
