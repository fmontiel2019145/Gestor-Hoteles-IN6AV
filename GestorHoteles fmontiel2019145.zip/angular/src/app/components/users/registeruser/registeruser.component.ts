import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';
import { UsersService } from 'src/app/services/users.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-registeruser',
  templateUrl: './registeruser.component.html',
  styleUrls: ['./registeruser.component.scss']
})
export class RegisteruserComponent implements OnInit {

  user: User = {
    idUsuario: "",
    apodoUsuario: "",
    nombreUsuario: "",
    correoUsuario: "",
    claveUsuario: "",
    fechaNacUsuario: new Date()
  };

  sesion: any = [];

  constructor(private userService: UsersService) {
    if(localStorage.getItem("token")){
      window.location.href = "home";
    }
  }

  ngOnInit(): void {
  }

  registerUser(){
    this.userService.register(this.user).subscribe(
      res => {
        this.sesion = res;
        if(this.sesion.token){
          localStorage.setItem("token", this.sesion.token);
          window.location.href = "home";
        }else{
          Swal.fire({
            title: 'Error!',
            text: 'Ya hay un usuario registrado con ese correo',
            icon: 'error',
            confirmButtonText: 'Ok'
          });
        }
      }, err => console.error(err)
    );
  }

}
