import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HotelsService } from 'src/app/services/hotels.service';
import { RoomsService } from 'src/app/services/rooms.service';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-reservateuser',
  templateUrl: './reservateuser.component.html',
  styleUrls: ['./reservateuser.component.scss']
})
export class ReservateuserComponent implements OnInit {

  habitacion: any = {
    idRoom : "",
    idUser : "",
    fechaEntradaPedido : null,
    fechaSalidaPedido : null,
    fechaEmisionPedido: new Date()
  };

  fechas: any = [];
  reservacciones: any = [];

  constructor(private roomsService: RoomsService, private router: ActivatedRoute, private hotelsService: HotelsService, private usersService: UsersService) { }

  ngOnInit(): void {
    this.usersService.getUser().subscribe(res => {
      var params: any = this.router.snapshot.params;
      this.habitacion.idRoom = params['idRoom'];
      this.habitacion.idUser = res['data']['_id'];

      this.roomsService.getRoom({idRoom : params['idRoom']}).subscribe(res => {
        this.fechas = res['data'];
        this.fechas.forEach(usuario => {
          usuario.pedidosUsuario.forEach(fecha => {
            if(fecha.fechaEntradaPedido && fecha.fechaSalidaPedido){
              this.reservacciones.push(fecha);
            }
          });
        });

        console.log(this.reservacciones);
      }, err => console.error(err));

    }, err => console.error(err));
    
  }

  reservate(){
    this.roomsService.addReservation(this.habitacion).subscribe(res => {
      location.reload();
    }, err => console.error(err));
    console.log(this.habitacion);
  }

}
