import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReservateuserComponent } from './reservateuser.component';

describe('ReservateuserComponent', () => {
  let component: ReservateuserComponent;
  let fixture: ComponentFixture<ReservateuserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReservateuserComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReservateuserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
