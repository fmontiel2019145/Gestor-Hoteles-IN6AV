import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from 'src/app/models/user';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-loginuser',
  templateUrl: './loginuser.component.html',
  styleUrls: ['./loginuser.component.scss']
})
export class LoginuserComponent implements OnInit {

  user: User = {
    idUsuario: "",
    apodoUsuario: "",
    nombreUsuario: "",
    correoUsuario: "",
    claveUsuario: "",
    fechaNacUsuario: new Date()
  };

  sesion: any;

  constructor(private usersService: UsersService, private router: ActivatedRoute) {
    if(localStorage.getItem("token")){
      window.location.href = "home";
    }
  }

  ngOnInit(): void {
  }

  loginUser(){
    this.usersService.login(this.user).subscribe(
      res => {
        this.sesion = res;
        console.log(this.sesion.token);
        localStorage.setItem("token", this.sesion.token);
        
          this.router.queryParams.subscribe(params => {
            if(params['next']){
              window.location.href = params['next'];
            }else{
              window.location.href = "home";
            }
          });
      }, err => console.error(err)
    );
  }
}

