import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-hotelhome',
  templateUrl: './hotelhome.component.html',
  styleUrls: ['./hotelhome.component.scss']
})
export class HotelhomeComponent implements OnInit {

  constructor(private usersService: UsersService) { }

  ngOnInit(): void {
    this.usersService.autoRedirect("home/client", false, "home/admin", "home");
  }

}
