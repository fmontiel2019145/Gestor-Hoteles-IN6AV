import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-defaulthome',
  templateUrl: './defaulthome.component.html',
  styleUrls: ['./defaulthome.component.scss']
})
export class DefaulthomeComponent implements OnInit {

  sesion: any;

  constructor(private usersService: UsersService) { }

  ngOnInit(): void {
    this.usersService.autoRedirect("home/client", "home/hotel", "home/admin", false);
  }
}
