export interface Hotels{
    _id : string,
    nombreHotel : string,
    descripcionHotel : string,
    direccionHotel : string,
    paisHotel : string,
    cpHotel : string,
    pbxHotel : number,
    calificacionesHotel : any,
    habitacionesHotel : any,
    eventosHotel : any
}