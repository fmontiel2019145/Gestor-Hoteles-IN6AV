export interface Habitaciones{
    idHotel : string,
    idHabitacion : string,
    descripcionHabitacion : string,
    categoriaHabitacion : string,
    costoHabitacion : number,
}