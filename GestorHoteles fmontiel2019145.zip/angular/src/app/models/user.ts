export interface User{
    idUsuario: string,
    apodoUsuario: string,
    nombreUsuario: string,
    correoUsuario: string,
    claveUsuario: string,
    fechaNacUsuario: Date
}