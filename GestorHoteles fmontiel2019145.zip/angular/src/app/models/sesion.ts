export interface Sesion{
    data: any,
    token: string,
    status: number,
    error: string
}